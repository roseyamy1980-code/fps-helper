package com.example.fpshelper;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String WRITE_SECURE = "android.permission.WRITE_SECURE_SETTINGS";
    private static final String PREFS = "fpshelper";
    private static final String KEY_LAST_GAME = "lastGame";

    private static final String[] CHECKLIST = {
            "Restart the Chromebook, then open only the game",
            "Close all other tabs and windows (Search + Esc ends heavy tasks)",
            "Plug in the charger; Battery Saver off",
            "Display: larger Display size / lower resolution",
            "Plain static wallpaper; screen saver and Night Light off",
            "Graphics acceleration on; chrome://gpu shows hardware acceleration",
            "Disable unneeded Chrome extensions; Memory Saver on for other tabs",
            "Keep 8-10 GB of storage free",
            "Turn off Linux if you don't use it",
            "Chromebook on a hard, cool surface",
            "In-game: cap FPS at 30 or 60, lower resolution, shadows/effects low, AA off",
            "No recording or streaming while playing"
    };

    private static final String[][] PAGES = {
            {"GPU status (check hardware acceleration)", "chrome://gpu"},
            {"Flags (experimental)", "chrome://flags"},
            {"Extensions (disable unneeded)", "chrome://extensions"},
            {"Performance (Memory Saver)", "chrome://settings/performance"},
            {"System (graphics acceleration)", "chrome://settings/system"},
            {"Display (resolution / size)", "chrome://os-settings/display"}
    };

    private static class AppEntry {
        final String label;
        final String pkg;
        AppEntry(String label, String pkg) {
            this.label = label;
            this.pkg = pkg;
        }
    }

    private SharedPreferences prefs;
    private int pad;
    private TextView stats;
    private TextView perf;
    private Button launchLast;
    private final List<CheckBox> checks = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        pad = (int) (16 * getResources().getDisplayMetrics().density);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("FPS Helper");
        title.setTextSize(24);
        root.addView(title);

        stats = new TextView(this);
        stats.setTextSize(16);
        stats.setPadding(0, pad, 0, pad / 2);
        root.addView(stats);

        perf = new TextView(this);
        perf.setTextSize(16);
        root.addView(perf);

        heading(root, "1. One-tap best FPS");
        addButton(root, "Boost & launch a game", v -> pickGame());
        launchLast = addButton(root, "Boost & launch last game", v -> {
            String last = prefs.getString(KEY_LAST_GAME, null);
            if (last == null) {
                pickGame();
            } else {
                launchGame(last);
            }
        });

        heading(root, "2. Android tools");
        addButton(root, "Boost only: close background Android apps", v -> boostOnly());
        addButton(root, "Low graphics: turn animations OFF", v -> setAnimations(0f));
        addButton(root, "Restore animations (normal)", v -> setAnimations(1f));
        addButton(root, "Developer options (limit background processes)",
                v -> open(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));
        addButton(root, "Storage settings", v -> open(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        addButton(root, "Manage apps (uninstall unused)",
                v -> open(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS));
        addButton(root, "Battery saver settings", v -> open(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        addButton(root, "Display settings", v -> open(Settings.ACTION_DISPLAY_SETTINGS));

        heading(root, "3. ChromeOS checklist (do before playing)");
        for (int i = 0; i < CHECKLIST.length; i++) {
            final int idx = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(CHECKLIST[i]);
            cb.setChecked(prefs.getBoolean("chk" + idx, false));
            cb.setOnCheckedChangeListener((b, checked) ->
                    prefs.edit().putBoolean("chk" + idx, checked).apply());
            checks.add(cb);
            root.addView(cb);
        }
        addButton(root, "Reset checklist", v -> {
            for (CheckBox cb : checks) {
                cb.setChecked(false);
            }
        });
        addButton(root, "Copy a Chrome / ChromeOS page address", v -> pickPage());

        TextView note = new TextView(this);
        note.setPadding(0, pad, 0, 0);
        note.setText("This app only affects the Android side of your Chromebook. It cannot change "
                + "ChromeOS graphics or raise a game's FPS directly, so the checklist covers the "
                + "ChromeOS steps. Copy a page address, then paste it into Chrome's address bar. "
                + "Keep the device cool and plugged in; thermal throttling is a common cause of "
                + "unstable FPS.");
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void heading(LinearLayout parent, String text) {
        TextView h = new TextView(this);
        h.setText(text);
        h.setTextSize(18);
        h.setPadding(0, pad, 0, pad / 2);
        parent.addView(h);
    }

    private Button addButton(LinearLayout parent, String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        parent.addView(b);
        return b;
    }

    private void refresh() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        StatFs fs = new StatFs(Environment.getDataDirectory().getPath());
        stats.setText(String.format(
                "RAM (Android side): %d MB free of %d MB%nStorage (Android side): %.1f GB free of %.1f GB%nLow memory: %s",
                mi.availMem / 1048576L, mi.totalMem / 1048576L,
                fs.getAvailableBytes() / 1073741824.0, fs.getTotalBytes() / 1073741824.0,
                mi.lowMemory ? "yes" : "no"));
        perf.setText(perfText());

        String last = prefs.getString(KEY_LAST_GAME, null);
        launchLast.setText(last == null
                ? "Boost & launch last game (none yet)"
                : "Boost & launch: " + labelFor(last));
    }

    private String perfText() {
        StringBuilder sb = new StringBuilder();

        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            int plugged = battery.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            if (temp > 0) {
                sb.append(String.format("Battery temp: %.1f C%n", temp / 10f));
            }
            sb.append("Plugged in: ").append(plugged != 0 ? "yes" : "no (plug in for full speed)").append("\n");
        }

        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            String[] names = {"none", "light", "moderate", "severe", "critical", "emergency", "shutdown"};
            int t = pm.getCurrentThermalStatus();
            sb.append("Thermal status: ")
                    .append(t >= 0 && t < names.length ? names[t] : String.valueOf(t))
                    .append("\n");
        }

        ContentResolver cr = getContentResolver();
        sb.append(String.format("Animation scales: window %.1f, transition %.1f, animator %.1f",
                Settings.Global.getFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, 1f),
                Settings.Global.getFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, 1f),
                Settings.Global.getFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)));
        return sb.toString();
    }

    private String labelFor(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (PackageManager.NameNotFoundException e) {
            return pkg;
        }
    }

    private int killBackground(String keep) {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        int count = 0;
        for (ApplicationInfo ai : getPackageManager().getInstalledApplications(0)) {
            if (ai.packageName.equals(getPackageName())) continue;
            if (keep != null && ai.packageName.equals(keep)) continue;
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            am.killBackgroundProcesses(ai.packageName);
            count++;
        }
        return count;
    }

    private void boostOnly() {
        int count = killBackground(null);
        Toast.makeText(this, "Asked " + count + " apps to close", Toast.LENGTH_SHORT).show();
        new Handler(Looper.getMainLooper()).postDelayed(this::refresh, 1000);
    }

    private void pickGame() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<AppEntry> entries = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            entries.add(new AppEntry(String.valueOf(ri.loadLabel(pm)), pkg));
        }
        Collections.sort(entries, (a, b) -> a.label.compareToIgnoreCase(b.label));
        if (entries.isEmpty()) {
            Toast.makeText(this, "No launchable apps found", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[entries.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = entries.get(i).label;
        }
        new AlertDialog.Builder(this)
                .setTitle("Pick a game to boost & launch")
                .setItems(labels, (d, which) -> launchGame(entries.get(which).pkg))
                .show();
    }

    private void launchGame(String pkg) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            Toast.makeText(this, "Can't launch that app", Toast.LENGTH_SHORT).show();
            return;
        }
        prefs.edit().putString(KEY_LAST_GAME, pkg).apply();
        int closed = killBackground(pkg);
        boolean animsOff = hasWriteSecure() && writeAnimationScale(0f);
        Toast.makeText(this, "Closed " + closed + " background apps"
                + (animsOff ? ", animations off" : ""), Toast.LENGTH_SHORT).show();
        startActivity(launch);
    }

    private boolean hasWriteSecure() {
        return checkSelfPermission(WRITE_SECURE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean writeAnimationScale(float scale) {
        try {
            ContentResolver cr = getContentResolver();
            Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, scale);
            Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, scale);
            Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, scale);
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    private void setAnimations(float scale) {
        if (!hasWriteSecure()) {
            showAdbDialog();
            return;
        }
        boolean ok = writeAnimationScale(scale);
        Toast.makeText(this, !ok ? "Permission denied by the system"
                : scale == 0f ? "Animations off" : "Animations restored", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void showAdbDialog() {
        final String cmd = "adb shell pm grant " + getPackageName() + " " + WRITE_SECURE;
        new AlertDialog.Builder(this)
                .setTitle("One-time setup needed")
                .setMessage("Android only lets this app change animation settings after you run this "
                        + "once from a computer or the Chromebook's Linux terminal with ADB connected:\n\n"
                        + cmd)
                .setPositiveButton("OK", null)
                .setNeutralButton("Copy command", (d, which) -> copy(cmd))
                .show();
    }

    private void pickPage() {
        String[] titles = new String[PAGES.length];
        for (int i = 0; i < PAGES.length; i++) {
            titles[i] = PAGES[i][0];
        }
        new AlertDialog.Builder(this)
                .setTitle("Copy an address, then paste it in Chrome")
                .setItems(titles, (d, which) -> copy(PAGES[which][1]))
                .show();
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("fpshelper", text));
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
    }

    private void open(String action) {
        try {
            startActivity(new Intent(action));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "That screen isn't available on this device", Toast.LENGTH_SHORT).show();
        }
    }
}
