# FPS Helper: everything for the best FPS on your Chromebook

One package: an Android app that does the automatic parts, plus the full
guide for the parts only you can change in ChromeOS.

## What the app does
- **Boost & launch:** pick a game; the app closes background Android apps,
  turns animations off (after the one-time setup below), and launches it.
  "Boost & launch last game" repeats it in one tap.
- Shows free RAM and storage, battery temperature, plugged-in state and
  thermal status, so you can spot throttling.
- Shortcuts: developer options, storage, apps, battery saver, display.
- Built-in ChromeOS checklist (saved between launches) and a button that
  copies chrome:// page addresses to paste into Chrome.

It cannot change ChromeOS settings or raise FPS directly. Animation changes
only affect Android apps.

## Get the APK
1. Create a new GitHub repo and push this folder to the `main` branch.
2. Open the repo's **Actions** tab, then the "Build APK" run.
3. Download the `fps-helper-debug-apk` artifact and unzip it.
Pushing a change rebuilds the APK automatically.

## Install on a Chromebook
Open `app-debug.apk` from the Files app. If that doesn't work, enable
Settings > Advanced > Developers > Android apps > ADB debugging, then run
`adb install app-debug.apk`.

## One-time setup for "animations off"
With ADB connected to the Chromebook, run:

    adb shell pm grant com.example.fpshelper android.permission.WRITE_SECURE_SETTINGS

Without it, everything else still works.

## ChromeOS: lower graphics load
- Settings > Device > Displays: larger "Display size" (lower effective
  resolution) or a lower resolution. Fewer pixels means higher, steadier FPS.
- Plain static wallpaper; screen saver and Night Light off.
- Settings > System: "Use graphics acceleration when available" on.
  chrome://gpu should show hardware acceleration for most items.
- Check Settings > Accessibility for any reduce-motion or animation option.
- Optional, experimental (chrome://flags, restart after, "Reset all" if worse):
  Override software rendering list, GPU rasterization, Zero-copy rasterizer.
  Turn Smooth Scrolling off.

## ChromeOS: steadier FPS
- Restart before playing, then open only the game.
- Search + Esc opens Task Manager: end heavy tabs and extensions.
- Chrome Settings > Performance: Memory Saver on for other tabs.
- Keep 8-10 GB of storage free.
- Plug in; Battery Saver off. Keep it cool on a hard surface.
- Turn off Linux (Settings > Advanced > Developers) and unused Android apps.
- Don't record or stream while playing.

## In-game
- Resolution / render scale: the biggest lever. Try 50-75% or 720p.
- Shadows, effects, view distance low; anti-aliasing off.
- Cap FPS at 30 or 60. A steady 30 beats a swinging 45.
- VSync off if you can tolerate tearing.

## By game type
- **Browser games:** Chrome only, fullscreen (F4), lightweight modes.
- **Cloud gaming:** FPS depends on Wi-Fi. Use 5 GHz close to the router, or a
  USB-Ethernet adapter. 720p stream.
- **Android games:** lower in-game graphics, run Boost & launch, pick lighter
  titles.

## Android developer options
Enable by tapping Build number in Android settings > About. Set animation
scales off and optionally "Background process limit" to at most 2 or 3.
Undo it if apps reload too often.

## Last resorts
Developer mode and Linux tweaks can weaken security, so skip them unless you
know the risks. Powerwash only if the system has become cluttered.

## Realistic expectations
The Celeron N4000 is an entry-level chip. After all of this, 2D, casual and
older games run smoothly; demanding 3D titles stay on low settings.
